class AppString{
  static String nameOf_shop = 'Flowerly ';
  static String loginScreen = ' Login ';
  static String loginScreenEmailTextFiled=' E-mail Address';
  static String loginScreenPasswordTextFiled='Password';
  static String signUpScreen = ' Sign Up ';
  static String confirmPasswordTextFiled = 'Confirm Password';
  static const appName = 'Flowerly 🌸';
  static const welcome = 'Welcome to Flowerly';
  static const login = 'Login';
  static const register = 'Register';
  static const home = 'Home';
  static const favorites = 'Favorites';
  static const cart = 'Cart';
  static const profile = 'Profile';
}